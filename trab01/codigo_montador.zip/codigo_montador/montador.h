#ifndef MONTADOR_H
#define MONTADOR_H

#include "token.h"

int processarEntrada(char*, unsigned);
int emitirMapaDeMemoria();

#endif
