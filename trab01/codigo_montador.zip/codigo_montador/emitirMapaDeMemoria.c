#include "montador.h"
#include <stdio.h>

/* Retorna:
 *  1 caso haja erro na montagem; 
 *  0 caso não haja erro.
 */
int emitirMapaDeMemoria()
{
  printf("Você deve implementar esta função para a parte 2.\n");
  return 0;
}
